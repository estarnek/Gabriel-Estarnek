@echo off
cd /d "%~dp0"
RobloxESP.exe --overlay-test
pause
