// C++17 | esp.cpp | Windows x64 | MSVC or MinGW-w64
#define UNICODE
#define _UNICODE
#define NOMINMAX
#include <windows.h>
#include <tlhelp32.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <regex>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

using Address = std::uint64_t;
struct Vec3 { float x, y, z; };
struct Matrix { float v[16]; };
struct Actor { std::wstring name; POINT top, bottom; };

class Memory {
    HANDLE process_ = nullptr;
public:
    Memory() = default;
    Memory(const Memory&) = delete;
    Memory& operator=(const Memory&) = delete;
    ~Memory() { close(); }
    void close() { if (process_) CloseHandle(process_); process_ = nullptr; }
    bool open(DWORD pid) {
        close();
        process_ = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
        return process_ != nullptr;
    }
    bool alive() const {
        DWORD code = 0;
        return process_ && GetExitCodeProcess(process_, &code) && code == STILL_ACTIVE;
    }
    bool read_bytes(Address p, void* out, SIZE_T n) const {
        if (!process_ || p < 0x10000 || p > 0x00007fffffffffffULL || n > 65536 || p + n < p) return false;
        SIZE_T count = 0;
        return ReadProcessMemory(process_, reinterpret_cast<LPCVOID>(p), out, n, &count) && count == n;
    }
    template<class T> bool read(Address p, T& value) const { return read_bytes(p, &value, sizeof(value)); }
    Address pointer(Address p) const { Address value = 0; return read(p, value) ? value : 0; }
    // MSVC x64 std::string layout. Reject unsupported layouts rather than scanning memory.
    std::string string(Address p) const {
        std::array<unsigned char, 32> header{};
        if (!read(p, header)) return {};
        Address length = 0, capacity = 0, data = p;
        memcpy(&length, header.data() + 16, 8);
        memcpy(&capacity, header.data() + 24, 8);
        if (length == 0 || length > 128 || capacity < length || capacity > 1048576) return {};
        if (capacity >= 16) memcpy(&data, header.data(), 8);
        std::string result(static_cast<size_t>(length), '\0');
        if (!read_bytes(data, result.data(), result.size())) return {};
        if (result.find('\0') != std::string::npos) return {};
        return result;
    }
    std::wstring path() const {
        std::wstring result(32768, L'\0'); DWORD size = static_cast<DWORD>(result.size());
        if (!QueryFullProcessImageNameW(process_, 0, result.data(), &size)) return {};
        result.resize(size); return result;
    }
};

std::map<std::string, Address> offsets;
Address off(const char* key) { return offsets.at(key); }
std::wstring directory;
bool enabled = false, team_filter = false, names = true, transpose = false;
COLORREF box_color = RGB(255, 80, 80);
int thickness = 2;
std::vector<Actor> actors;
std::wstring status_text = L"F6: ligar ESP | F7: equipe | END: sair";

std::wstring wide(const std::string& text) {
    int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()), nullptr, 0);
    if (n <= 0) return L"Jogador";
    std::wstring result(n, L'\0');
    MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()), result.data(), n);
    return result;
}

std::vector<Address> children(const Memory& mem, Address object) {
    Address container = mem.pointer(object + off("Instance.ChildrenStart"));
    Address start = mem.pointer(container), end = mem.pointer(container + off("Instance.ChildrenEnd"));
    if (start < 0x10000 || end < start || end - start > 16 * 4096 || (end - start) % 16) return {};
    std::vector<Address> result;
    for (Address p = start; p < end; p += 16) {
        Address child = mem.pointer(p);
        if (child >= 0x10000) result.push_back(child);
    }
    return result;
}
std::string class_name(const Memory& mem, Address object) {
    Address descriptor = mem.pointer(object + off("Instance.ClassDescriptor"));
    return mem.string(mem.pointer(descriptor + off("Instance.ClassName")));
}
std::string instance_name(const Memory& mem, Address object) {
    Address container = mem.pointer(object + off("Instance.NameContainer"));
    auto name = mem.string(container + off("Instance.Name"));
    if (name.empty()) name = mem.string(mem.pointer(container + off("Instance.Name")));
    return name;
}
bool project(Vec3 p, const Matrix& m, int width, int height, POINT& out) {
    auto at = [&](int r, int c) { return m.v[transpose ? c * 4 + r : r * 4 + c]; };
    float x = at(0,0)*p.x + at(0,1)*p.y + at(0,2)*p.z + at(0,3);
    float y = at(1,0)*p.x + at(1,1)*p.y + at(1,2)*p.z + at(1,3);
    float w = at(3,0)*p.x + at(3,1)*p.y + at(3,2)*p.z + at(3,3);
    if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(w) || w < 0.01f) return false;
    float sx = (x/w + 1.f)*0.5f*width, sy = (1.f - y/w)*0.5f*height;
    if (!std::isfinite(sx) || !std::isfinite(sy) || sx < -width || sx > width*2.f || sy < -height || sy > height*2.f) return false;
    out = { static_cast<LONG>(sx), static_cast<LONG>(sy) }; return true;
}

DWORD find_process() {
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W entry{}; entry.dwSize = sizeof(entry); DWORD pid = 0;
    if (Process32FirstW(snapshot, &entry)) do {
        if (_wcsicmp(entry.szExeFile, L"RobloxPlayerBeta.exe") == 0) { pid = entry.th32ProcessID; break; }
    } while (Process32NextW(snapshot, &entry));
    CloseHandle(snapshot); return pid;
}
Address module_base(DWORD pid) {
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
    if (snapshot == INVALID_HANDLE_VALUE) return 0;
    MODULEENTRY32W entry{}; entry.dwSize = sizeof(entry); Address base = 0;
    if (Module32FirstW(snapshot, &entry)) do {
        if (_wcsicmp(entry.szModule, L"RobloxPlayerBeta.exe") == 0) {
            base = reinterpret_cast<Address>(entry.modBaseAddr); break;
        }
    } while (Module32NextW(snapshot, &entry));
    CloseHandle(snapshot); return base;
}
struct WindowSearch { DWORD pid; HWND window; };
HWND find_window(DWORD pid) {
    WindowSearch search{pid, nullptr};
    EnumWindows([](HWND window, LPARAM data)->BOOL {
        auto& search = *reinterpret_cast<WindowSearch*>(data);
        DWORD owner = 0; GetWindowThreadProcessId(window, &owner);
        if (owner == search.pid && IsWindowVisible(window) && GetWindow(window, GW_OWNER) == nullptr) {
            search.window = window; return FALSE;
        }
        return TRUE;
    }, reinterpret_cast<LPARAM>(&search));
    return search.window;
}

void sample(const Memory& mem, Address base, int width, int height) {
    actors.clear();
    if (!enabled) { status_text = L"ESP DESLIGADO | F6: ligar | END: sair"; return; }
    Address fake = mem.pointer(base + off("FakeDataModel.Pointer"));
    Address model = mem.pointer(fake + off("FakeDataModel.RealDataModel"));
    Address engine = mem.pointer(base + off("VisualEngine.Pointer"));
    Matrix matrix{};
    if (!model || !engine || !mem.read(engine + off("VisualEngine.ViewMatrix"), matrix)) {
        status_text = L"Sem dados: entre em uma partida ou confira a versao/offsets."; return;
    }
    Address players = 0;
    for (Address child : children(mem, model)) {
        if (class_name(mem, child) == "Players") { players = child; break; }
    }
    if (!players) { status_text = L"Players nao localizado: offsets/layout incompativeis ou jogo carregando."; return; }
    Address local = mem.pointer(players + off("Player.LocalPlayer"));
    if (!local) { status_text = L"Aguardando jogador local."; return; }
    Address local_team = mem.pointer(local + off("Player.Team"));
    unsigned candidates = 0;
    for (Address player : children(mem, players)) {
        if (player == local || class_name(mem, player) != "Player") continue;
        if (team_filter && local_team && mem.pointer(player + off("Player.Team")) == local_team) continue;
        ++candidates;
        Address character = mem.pointer(player + off("Player.ModelInstance"));
        if (!character) continue;
        Address root = 0, humanoid = 0;
        for (Address part : children(mem, character)) {
            if (instance_name(mem, part) == "HumanoidRootPart") root = part;
            if (class_name(mem, part) == "Humanoid") humanoid = part;
        }
        float health = 0;
        if (humanoid && mem.read(humanoid + off("Humanoid.Health"), health) && health <= 0) continue;
        if (!root) continue;
        Address primitive = mem.pointer(root + off("BasePart.Primitive"));
        Vec3 position{};
        if (!mem.read(primitive + off("Primitive.Position"), position)) continue;
        if (!std::isfinite(position.x) || !std::isfinite(position.y) || !std::isfinite(position.z)) continue;
        // Approximate upright avatar box, not an exact mesh bounding box.
        Actor actor{};
        if (!project({position.x, position.y+3.f, position.z}, matrix, width, height, actor.top)
            || !project({position.x, position.y-3.f, position.z}, matrix, width, height, actor.bottom)) continue;
        if (actor.bottom.y - actor.top.y < 3) continue;
        actor.name = names ? wide(instance_name(mem, player)) : L"";
        actors.push_back(std::move(actor));
    }
    status_text = L"ESP LIGADO | F6: desligar | F7 equipe: " + std::wstring(team_filter ? L"ON" : L"OFF")
        + L" | visiveis: " + std::to_wstring(actors.size()) + L"/" + std::to_wstring(candidates) + L" | END: sair";
}

LRESULT CALLBACK window_proc(HWND window, UINT message, WPARAM wp, LPARAM lp) {
    if (message == WM_NCHITTEST) return HTTRANSPARENT;
    if (message == WM_ERASEBKGND) return 1;
    if (message == WM_DESTROY) { PostQuitMessage(0); return 0; }
    if (message == WM_PAINT) {
        PAINTSTRUCT paint{}; HDC screen = BeginPaint(window, &paint);
        RECT rect{}; GetClientRect(window, &rect);
        if (rect.right > 0 && rect.bottom > 0) {
            HDC buffer = CreateCompatibleDC(screen);
            HBITMAP bitmap = CreateCompatibleBitmap(screen, rect.right, rect.bottom);
            HGDIOBJ old_bitmap = SelectObject(buffer, bitmap);
            FillRect(buffer, &rect, static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));
            SetBkMode(buffer, TRANSPARENT); SetTextColor(buffer, RGB(255,255,255));
            HGDIOBJ old_font = SelectObject(buffer, GetStockObject(DEFAULT_GUI_FONT));
            TextOutW(buffer, 14, 14, status_text.c_str(), static_cast<int>(status_text.size()));
            HPEN pen = CreatePen(PS_SOLID, thickness, box_color);
            HGDIOBJ old_pen = SelectObject(buffer, pen);
            HGDIOBJ old_brush = SelectObject(buffer, GetStockObject(NULL_BRUSH));
            for (const auto& actor : actors) {
                int height = actor.bottom.y - actor.top.y;
                int half_width = std::max(2, height / 4);
                int center = (actor.top.x + actor.bottom.x) / 2;
                Rectangle(buffer, center-half_width, actor.top.y, center+half_width, actor.bottom.y);
                if (!actor.name.empty()) {
                    SIZE size{}; GetTextExtentPoint32W(buffer, actor.name.c_str(), static_cast<int>(actor.name.size()), &size);
                    TextOutW(buffer, center-size.cx/2, actor.top.y-size.cy-2, actor.name.c_str(), static_cast<int>(actor.name.size()));
                }
            }
            BitBlt(screen, 0, 0, rect.right, rect.bottom, buffer, 0, 0, SRCCOPY);
            SelectObject(buffer, old_brush); SelectObject(buffer, old_pen); DeleteObject(pen);
            SelectObject(buffer, old_font); SelectObject(buffer, old_bitmap);
            DeleteObject(bitmap); DeleteDC(buffer);
        }
        EndPaint(window, &paint); return 0;
    }
    return DefWindowProcW(window, message, wp, lp);
}

int main() {
    SetProcessDPIAware();
    wchar_t executable[32768]{};
    GetModuleFileNameW(nullptr, executable, 32768);
    directory = executable; directory = directory.substr(0, directory.find_last_of(L"\\/") + 1);
    SetCurrentDirectoryW(directory.c_str());
    try {
        std::ifstream input("roblox-offsets.json");
        if (!input) throw std::runtime_error("roblox-offsets.json ausente ao lado do EXE.");
        std::string json((std::istreambuf_iterator<char>(input)), {});
        const std::regex pattern(R"rx("([A-Za-z0-9_.]+)"\s*:\s*"([0-9]+)")rx");
        for (auto it = std::sregex_iterator(json.begin(), json.end(), pattern); it != std::sregex_iterator(); ++it)
            offsets[(*it)[1].str()] = std::stoull((*it)[2].str());
        for (const char* key : {"FakeDataModel.Pointer", "FakeDataModel.RealDataModel", "VisualEngine.Pointer",
            "VisualEngine.ViewMatrix", "Instance.ChildrenStart", "Instance.ChildrenEnd", "Instance.ClassDescriptor",
            "Instance.ClassName", "Instance.NameContainer", "Instance.Name", "Player.LocalPlayer", "Player.Team",
            "Player.ModelInstance", "BasePart.Primitive", "Primitive.Position", "Humanoid.Health"}) (void)off(key);
        std::smatch version_match;
        if (!std::regex_search(json, version_match, std::regex(R"rx("version"\s*:\s*"(version-[a-fA-F0-9]+)")rx")))
            throw std::runtime_error("Versao ausente/invalida no JSON.");
        std::wstring required_version = wide(version_match[1].str());
        std::wstring ini = directory + L"esp.ini";
        enabled = GetPrivateProfileIntW(L"ESP", L"Enabled", 0, ini.c_str()) != 0;
        team_filter = GetPrivateProfileIntW(L"ESP", L"TeamFilter", 0, ini.c_str()) != 0;
        names = GetPrivateProfileIntW(L"ESP", L"Names", 1, ini.c_str()) != 0;
        transpose = GetPrivateProfileIntW(L"ESP", L"TransposeMatrix", 0, ini.c_str()) != 0;
        thickness = std::clamp(static_cast<int>(GetPrivateProfileIntW(L"ESP", L"Thickness", 2, ini.c_str())), 1, 6);
        auto color = [&](const wchar_t* key, int fallback) {
            return std::clamp(static_cast<int>(GetPrivateProfileIntW(L"ESP", key, fallback, ini.c_str())), 1, 255);
        };
        box_color = RGB(color(L"Red", 255), color(L"Green", 80), color(L"Blue", 80));
        std::cout << "Roblox ESP externo x64\nF6: ligar/desligar | F7: filtro de equipe | END: sair\n"
            << "Abra o Roblox em modo janela ou sem bordas. Aguardando processo...\n";
        Memory memory; DWORD pid = 0; Address base = 0; HWND game = nullptr;
        WNDCLASSW wc{}; wc.lpfnWndProc = window_proc; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"ExternalESPWindow";
        if (!RegisterClassW(&wc)) throw std::runtime_error("Falha ao registrar janela.");
        HWND overlay = CreateWindowExW(WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
            wc.lpszClassName, L"ESP", WS_POPUP, 0, 0, 1, 1, nullptr, nullptr, wc.hInstance, nullptr);
        if (!overlay) throw std::runtime_error("Falha ao criar overlay.");
        if (!SetLayeredWindowAttributes(overlay, RGB(0,0,0), 255, LWA_COLORKEY))
            throw std::runtime_error("Falha ao configurar transparencia.");
        // Global hotkeys avoid injecting hooks into the game.
        if (!RegisterHotKey(overlay, 1, MOD_NOREPEAT, VK_F6)
            || !RegisterHotKey(overlay, 2, MOD_NOREPEAT, VK_F7)
            || !RegisterHotKey(overlay, 3, MOD_NOREPEAT, VK_END))
            throw std::runtime_error("F6, F7 ou END ja esta em uso por outro aplicativo. Feche outra instancia.");
        bool running = true; ULONGLONG next_attach = 0;
        while (running) {
            MSG message{};
            while (PeekMessageW(&message, nullptr, 0, 0, PM_REMOVE)) {
                if (message.message == WM_QUIT) running = false;
                if (message.message == WM_HOTKEY) {
                    if (message.wParam == 1) enabled = !enabled;
                    if (message.wParam == 2) team_filter = !team_filter;
                    if (message.wParam == 3) running = false;
                }
                TranslateMessage(&message); DispatchMessageW(&message);
            }
            if (!running) break;
            if (!memory.alive() || !IsWindow(game)) {
                ShowWindow(overlay, SW_HIDE); actors.clear();
                if (GetTickCount64() >= next_attach) {
                    next_attach = GetTickCount64() + 1500;
                    pid = find_process();
                    if (pid) {
                        if (!memory.open(pid)) throw std::runtime_error("OpenProcess negado. Nao foi possivel ler o cliente (sem bypass).");
                        std::wstring path = memory.path();
                        if (path.empty() || path.find(required_version + L"\\") == std::wstring::npos)
                            throw std::runtime_error("Versao do cliente diferente do JSON, ou caminho nao verificavel. Atualize os offsets antes de usar.");
                        base = module_base(pid); game = find_window(pid);
                        if (!base) throw std::runtime_error("Nao foi possivel localizar o modulo RobloxPlayerBeta.exe.");
                        if (game) std::cout << "Processo localizado; versao do diretorio confere com o JSON.\n";
                    }
                }
                Sleep(100); continue;
            }
            RECT rect{}; POINT origin{};
            if (GetForegroundWindow() != game || IsIconic(game) || !GetClientRect(game, &rect)
                || !ClientToScreen(game, &origin) || rect.right < 1 || rect.bottom < 1) {
                ShowWindow(overlay, SW_HIDE); Sleep(60); continue;
            }
            sample(memory, base, rect.right, rect.bottom);
            SetWindowPos(overlay, HWND_TOPMOST, origin.x, origin.y, rect.right, rect.bottom, SWP_NOACTIVATE | SWP_SHOWWINDOW);
            InvalidateRect(overlay, nullptr, FALSE); UpdateWindow(overlay);
            Sleep(33);
        }
        WritePrivateProfileStringW(L"ESP", L"Enabled", enabled ? L"1" : L"0", ini.c_str());
        WritePrivateProfileStringW(L"ESP", L"TeamFilter", team_filter ? L"1" : L"0", ini.c_str());
        for (int id : {1,2,3}) UnregisterHotKey(overlay, id);
        DestroyWindow(overlay);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Erro: " << error.what() << "\n";
        MessageBoxA(nullptr, error.what(), "Roblox ESP - erro", MB_OK | MB_ICONERROR);
        return 1;
    }
}
