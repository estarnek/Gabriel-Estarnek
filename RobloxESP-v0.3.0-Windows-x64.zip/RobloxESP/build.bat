@echo off
setlocal
cd /d "%~dp0"
where cl >nul 2>nul
if not errorlevel 1 goto build
if not exist "%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" goto missing
for /f "usebackq delims=" %%I in (`"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do call "%%I\VC\Auxiliary\Build\vcvars64.bat"
where cl >nul 2>nul
if errorlevel 1 goto missing
:build
if /i not "%VSCMD_ARG_TGT_ARCH%"=="x64" (
  echo Execute no x64 Native Tools Command Prompt do Visual Studio.
  pause
  exit /b 1
)
cl /nologo /std:c++17 /EHsc /W4 /O2 /MT /utf-8 esp.cpp /Fe:RobloxESP.exe user32.lib gdi32.lib
if errorlevel 1 (
  pause
  exit /b 1
)
echo Pronto: RobloxESP.exe
pause
exit /b 0
:missing
echo Instale Visual Studio Build Tools com Desenvolvimento para desktop com C++ e Windows SDK.
pause
exit /b 1
